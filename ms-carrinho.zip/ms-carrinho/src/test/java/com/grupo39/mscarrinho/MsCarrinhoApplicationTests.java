package com.grupo39.mscarrinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCarrinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
