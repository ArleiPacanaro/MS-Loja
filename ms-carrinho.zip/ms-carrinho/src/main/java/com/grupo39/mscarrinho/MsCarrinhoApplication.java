package com.grupo39.mscarrinho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCarrinhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCarrinhoApplication.class, args);
	}

}
